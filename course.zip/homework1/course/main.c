/**
 * @file main.c
 * @author wesley yang
 * @brief 
 * @version 0.1
 * @date 2022-04-15
 * @copyright Copyright (c) 2022
 */
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief The main entry to the program
 * 
 * @return int 
 */
int main()
{
  srand((unsigned) time(NULL));// Initialize the random number generator

  Course *MATH101 = calloc(1, sizeof(Course)); // Dynamically allocated memory
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");
  
  /* construct 20 students data, each student has 8 grades */
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  /* print all the data for the course */
  print_course(MATH101);

  Student *student;
  student = top_student(MATH101); // get data about the student with highest scores
  printf("\n\nTop student: \n\n");
  
  /* print the data of student with highest grades */
  print_student(student);

  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing); //get data on students with scores above 50
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");

  /*print data for students with scores above 50 */
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}