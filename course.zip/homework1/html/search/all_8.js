var searchData=
[
  ['top_5fstudent_0',['top_student',['../course_8c.html#ac1d82150824c7ecd43bab36fb83cd779',1,'top_student(Course *course):&#160;course.c'],['../course_8h.html#ac1d82150824c7ecd43bab36fb83cd779',1,'top_student(Course *course):&#160;course.c']]]
];
