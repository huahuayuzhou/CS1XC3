/**
 * @file course.h
 * @author zhaohe yang
 * @brief 
 * @version 0.1
 * @date 2022-04-15
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "student.h"
#include <stdbool.h>

/**
 * @struct
 * @brief Define a type with four members
 * 
 */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students; // students array
  int total_students;
} Course;

/**
 * @fn
 * @brief dynamic storage of student data
 * 
 * @param course 
 * @param student 
 */
void enroll_student(Course *course, Student *student);

/**
 * @fn
 * @brief print all the data for the course
 * 
 * @param course 
 */
void print_course(Course *course);

/**
 * @fn
 * @brief get data about the student with highest scores
 * 
 * @param course 
 * @return Student* 
 */
Student *top_student(Course* course);

/**
 * @fn
 * @brief get data on students with scores above 50
 * 
 * @param course 
 * @param total_passing 
 * @return Student* 
 */
Student *passing(Course* course, int *total_passing);


