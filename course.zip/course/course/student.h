/**
 * @file student.h
 * @author zhaohe yang
 * @brief 
 * @version 0.1
 * @date 2022-04-15
 * 
 * @copyright Copyright (c) 2022
 * 
 */
 
 /**
  * @struct
  * @brief Define a Student type with five members
  * 
  */
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; //scores array
  int num_grades; 
} Student;

/**
 * @fn
 * @brief Dynamic increase in academic performance
 * 
 * @param student 
 * @param grade 
 */
void add_grade(Student *student, double grade);

/**
 * @fn
 * @brief calculate the average grade of the student
 * 
 * @param student 
 * @return double 
 */
double average(Student *student);

/**
 * @fn
 * @brief print all information about a student
 * 
 * @param student 
 */
void print_student(Student *student);

/**
 * @fn
 * @brief Generate a random student data
 * 
 * @param grades 
 * @return Student* 
 */
Student* generate_random_student(int grades); 
